from django.contrib import admin

# Register your models here.
from django_sliders.slider.models import Slider

admin.site.register(Slider)